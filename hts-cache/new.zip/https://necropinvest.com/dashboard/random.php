<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <!-- <p style="background: #f0eeee; padding: 10px; width: 300px; border-radius: 5px; border: 1px solid dodgerblue; font-family: Trebuchet MS; display: flex"><img src="../images/bitcoin_icon.png" width="50px"><span id='demo'></span>Fernandez David from Tunisia just deposited $23,600</b></p> -->

    <p style="background: #f0eeee; padding: 10px; width: 300px; border-radius: 5px; border: 1px solid dodgerblue; font-family: Trebuchet MS; display: flex"><img src="../images/bitcoin_icon.png" width="50px"> Fernandez David from Tunisia just deposited $23,600</p>

    

<script>
    var demo = document.getElementById('demo');
    // var xhr = new XMLHttpRequest();
    // xhr.onreadystatechange = function () {
    //    demo.textContent = xhr.responseText(); 
    //    console.log(xhr.responseText)
    // }
    // xhr.open("GET", "test3.php", true)
    // xhr.send()

    var name = "https://localhost/capitalxch/test3.php"
        fetch(name)
    .then(response => response.json())
    .then(data => console.log(demo.textContent = data.username));

</script>


</body>
</html>